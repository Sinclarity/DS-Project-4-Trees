//Project 4
//Description: Exception
//Author: Peter Schurhammer

package project4;

public class FTableException extends RuntimeException {
    public FTableException(String s) {
        super(s);
    }
} //end FTableException
